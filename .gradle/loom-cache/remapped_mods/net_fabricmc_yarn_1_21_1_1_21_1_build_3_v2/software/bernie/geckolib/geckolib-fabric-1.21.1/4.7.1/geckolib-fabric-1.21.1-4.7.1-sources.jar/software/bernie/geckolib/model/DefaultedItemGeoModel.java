package software.bernie.geckolib.model;

import net.minecraft.util.Identifier;
import software.bernie.geckolib.animatable.GeoAnimatable;

/**
 * {@link DefaultedGeoModel} specific to {@link net.minecraft.item.Item Items}
 * <p>
 * Using this class pre-sorts provided asset paths into the "item" subdirectory
 */
public class DefaultedItemGeoModel<T extends GeoAnimatable> extends DefaultedGeoModel<T> {
	/**
	 * Create a new instance of this model class
	 * <p>
	 * The asset path should be the truncated relative path from the base folder
	 * <p>
	 * E.G.
	 * <pre>{@code
	 * 	new ResourceLocation("myMod", "armor/obsidian")
	 * }</pre>
	 */
	public DefaultedItemGeoModel(Identifier assetSubpath) {
		super(assetSubpath);
	}

	/**
	 * Returns the subtype string for this type of model
	 * <p>
	 * This allows for sorting of asset files into neat subdirectories for clean management
	 */
	@Override
	protected String subtype() {
		return "item";
	}

	/**
	 * Changes the constructor-defined model path for this model to an alternate
	 * <p>
	 * This is useful if your animatable shares a model path with another animatable that differs in path to the texture and animations for this model
	 */
	@Override
	public DefaultedItemGeoModel<T> withAltModel(Identifier altPath) {
		return (DefaultedItemGeoModel<T>)super.withAltModel(altPath);
	}

	/**
	 * Changes the constructor-defined animations path for this model to an alternate
	 * <p>
	 * This is useful if your animatable shares an animations path with another animatable that differs in path to the model and texture for this model
	 */
	@Override
	public DefaultedItemGeoModel<T> withAltAnimations(Identifier altPath) {
		return (DefaultedItemGeoModel<T>)super.withAltAnimations(altPath);
	}

	/**
	 * Changes the constructor-defined texture path for this model to an alternate
	 * <p>
	 * This is useful if your animatable shares a texture path with another animatable that differs in path to the model and animations for this model
	 */
	@Override
	public DefaultedItemGeoModel<T> withAltTexture(Identifier altPath) {
		return (DefaultedItemGeoModel<T>)super.withAltTexture(altPath);
	}
}
