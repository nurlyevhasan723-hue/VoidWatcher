package software.bernie.geckolib.renderer.layer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.texture.AutoGlowingTexture;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.util.ClientUtil;

/**
 * {@link GeoRenderLayer} for rendering the auto-generated glowlayer functionality implemented by Geckolib using the <i>_glowing</i> appendixed texture files
 *
 * @see <a href="https://github.com/bernie-g/geckolib/wiki/Emissive-Textures-Glow-Layer">GeckoLib Wiki - Glow Layers</a>
 */
public class AutoGlowingGeoLayer<T extends GeoAnimatable> extends GeoRenderLayer<T> {
	public AutoGlowingGeoLayer(GeoRenderer<T> renderer) {
		super(renderer);
	}

	/**
	 * Get the render type to use for this glowlayer renderer
	 * <p>
	 * Uses a custom RenderType similar to {@link RenderLayer#getEyes(Identifier)} by default, which may not be ideal in all circumstances
	 * @deprecated Use {@link #getRenderType(GeoAnimatable, VertexConsumerProvider)}
	 */
	@Deprecated(forRemoval = true)
	protected RenderLayer getRenderType(T animatable) {
		return getRenderType(animatable, null);
	}

	/**
	 * Get the render type to use for this glowlayer renderer, or null if the layer should not render
	 * <p>
	 * Uses a custom RenderType similar to {@link RenderLayer#getEyes(Identifier)} by default, which may not be ideal in all circumstances.<br>
	 * Automatically accounts for entity states like invisibility and glowing
	 *
	 * @param bufferSource Nullable until {@link #getRenderType(GeoAnimatable)} is removed for backward compatibility
	 */
	@Nullable
	protected RenderLayer getRenderType(T animatable, @Nullable VertexConsumerProvider bufferSource) {
		if (!(animatable instanceof Entity entity))
			return AutoGlowingTexture.getRenderType(getTextureResource(animatable));

		boolean invisible = entity.isInvisible();
		Identifier texture = AutoGlowingTexture.getEmissiveResource(getTextureResource(animatable));

		if (invisible && !entity.isInvisibleTo(ClientUtil.getClientPlayer()))
			return RenderLayer.getItemEntityTranslucentCull(texture);

		if (MinecraftClient.getInstance().hasOutline(entity)) {
			if (invisible)
				return RenderLayer.getOutline(texture);

			return AutoGlowingTexture.getOutlineRenderType(getTextureResource(animatable));
		}

		return invisible ? null : AutoGlowingTexture.getRenderType(getTextureResource(animatable));
	}

	/**
	 * This is the method that is actually called by the render for your render layer to function
	 * <p>
	 * This is called <i>after</i> the animatable has been rendered, but before supplementary rendering like nametags
	 */
	@Override
	public void render(MatrixStack poseStack, T animatable, BakedGeoModel bakedModel, @Nullable RenderLayer renderType, VertexConsumerProvider bufferSource, @Nullable VertexConsumer buffer, float partialTick, int packedLight, int packedOverlay) {
		renderType = getRenderType(animatable);

		if (renderType != null) {
			getRenderer().reRender(bakedModel, poseStack, bufferSource, animatable, renderType,
					bufferSource.getBuffer(renderType), partialTick, 15728640, packedOverlay,
					getRenderer().getRenderColor(animatable, partialTick, packedLight).argbInt());
		}
	}
}
